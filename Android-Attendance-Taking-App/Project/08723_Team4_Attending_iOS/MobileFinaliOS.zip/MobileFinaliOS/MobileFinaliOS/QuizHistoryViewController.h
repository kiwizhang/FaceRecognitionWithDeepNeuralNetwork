//
//  QuizHistoryViewController.h
//  MobileFinaliOS
//
//  Created by Wei YuYen on 2016/7/30.
//  Copyright © 2016年 Carnegie Mellon University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuizHistoryViewController : UITableViewController

- (void) setSelectCourse: (id) selectCourse;

@end
