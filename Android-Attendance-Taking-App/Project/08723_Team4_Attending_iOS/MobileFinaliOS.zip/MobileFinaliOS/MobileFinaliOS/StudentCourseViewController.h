//
//  StudentCourseViewController.h
//  MobileFinaliOS
//
//  Created by Wei YuYen on 2016/7/21.
//  Copyright © 2016年 Carnegie Mellon University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StudentCourseViewController : UITableViewController<UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *studentCourseView;

@end
